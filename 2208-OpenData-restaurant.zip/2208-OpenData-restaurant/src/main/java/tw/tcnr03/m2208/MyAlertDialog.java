package tw.tcnr03.m2208;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

public class MyAlertDialog extends AlertDialog {

    protected MyAlertDialog(@NonNull Context context) {
        super(context);
    }
}